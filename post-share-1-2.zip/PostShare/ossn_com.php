<?php
/*
* file location: components/PostShare/
*/
define('__OSSN_POST_SHARE__', ossn_route()->com . 'PostShare/');
require_once(__OSSN_POST_SHARE__ . 'classes/PostShare.php');

function ossn_shares() {
    if (ossn_isLoggedin()) {
        ossn_register_action('post/share', __OSSN_POST_SHARE__ . 'actions/post/share.php');
    }
	ossn_extend_view('css/ossn.default', 'css/postshare');
	ossn_extend_view('js/opensource.socialnetwork', 'js/postshare');
	ossn_register_callback('wall', 'load:item', 'ossn_wall_share_menu');
}

function ossn_wall_share_menu($callback, $type, $params){
	$guid = $params['post']->guid;
	ossn_unregister_menu('share', 'postextra');
	ossn_register_menu_item('postextra', array(
					'data-toggle' => 'dropdown', 
					'name' => 'share', 
					'href' => "javascript:void(0);",
					'id' => 'ossn-share-'.$guid,
					//'onclick' => "Ossn.PostShare({$guid});",
					'text' => "Share",
			));
}
ossn_register_callback('ossn', 'init', 'ossn_shares');