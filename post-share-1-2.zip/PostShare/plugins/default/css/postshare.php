

li.postShareLi{float:right;position:relative;}
li.postShareLi:after{
	font-family: FontAwesome;
	content: "\f064" !important;
	display: inline-block;
	padding-right: 10px;
	vertical-align: middle;
	font-size: 16px;
}

.share_pops_privacy a{padding:4px 6px;}
.share_pops_privacy a:hover{cursor:pointer;}
.share_link_wrapper{padding:4px 6px;}