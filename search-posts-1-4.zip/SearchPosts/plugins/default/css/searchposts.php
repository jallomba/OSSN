.ossn-menu-search-posts .text::before {
    font-family: FontAwesome;
    content: "\f075";
    display: absolute;
    padding-right: 10px;
    vertical-align: middle;
    float: left;
}