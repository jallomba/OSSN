<?php
/*
* file location: components/PostShare/classes
*/
class PostShare extends OssnObject {
	public function Post($post, $friends = '', $location = '', $access = '', $wallphoto = '') {
		$this->type = 'user';
		if(empty($access)) {
				$access = OSSN_PUBLIC;
		}
		$canpost = false;
		if(strlen($post)) {
				$canpost = true;
		}
		if(is_array($wallphoto)) {
				$canpost = true;
		}
		if(empty($this->owner_guid) || empty($this->poster_guid) || $canpost === false) {
				return false;
		}
		if(isset($this->item_type) && !empty($this->item_type)) {
				$this->data->item_type = $this->item_type;
		}
		if(isset($this->item_guid) && !empty($this->item_guid)) {
				$this->data->item_guid = $this->item_guid;
		}
		$this->data->poster_guid  = $this->poster_guid;
		$this->data->access       = $access;
		$this->data->time_updated = 0;
		$this->subtype            = 'wall';
		$this->title              = '';
		
		$post             = preg_replace('/\t/', ' ', $post);
		$wallpost['post'] = htmlspecialchars($post, ENT_QUOTES, 'UTF-8');
		
		//wall tag a friend , GUID issue #566
		if(!empty($friends)) {
				$friend_guids = explode(',', $friends);
				//reset friends guids
				$friends      = array();
				foreach($friend_guids as $guid) {
						if(ossn_user_by_guid($guid)) {
								$friends[] = $guid;
						}
				}
				$wallpost['friend'] = implode(',', $friends);
		}
		if(!empty($location)) {
				$wallpost['location'] = $location;
		}
		//Encode multibyte Unicode characters literally (default is to escape as \uXXXX)
		$this->description = json_encode($wallpost, JSON_UNESCAPED_UNICODE);
		if($this->addObject()) {
				$this->wallguid = $this->getObjectId();
				if(isset($wallphoto['base_path_file_photo'])) {
					$base_path = $wallphoto['base_path_file_photo'] . $this->wallguid . '/ossnwall/images/';
					$wallphoto_filenewname = $wallphoto['file_new_name'];
					mkdir($base_path, 0755, true);
					if(copy($wallphoto['path_file_photo_orig'], $base_path . $wallphoto_filenewname)){
						$timeentry = time();
						$this->statement("INSERT INTO ossn_entities (`owner_guid`, `type`, `subtype`, `time_created`, `time_updated`, `permission`, `active`)
							   VALUES('".$this->wallguid."', 'object', 'file:wallphoto', '".$timeentry."', '0', '2', '1');");
						$this->execute();
						
						$this->statement("INSERT INTO ossn_entities_metadata (`guid`, `value`)
							   VALUES('".$this->last_id."', 'ossnwall/images/".$wallphoto_filenewname."');");
						$this->execute();
					}
				}
				$params['object_guid'] = $this->wallguid;
				$params['poster_guid'] = $this->poster_guid;
				if(isset($wallpost['friend'])) {
						$params['friends'] = explode(',', $wallpost['friend']);
				}
				ossn_trigger_callback('wall', 'post:created', $params);
				return $this->wallguid;
		}
		return true;
	}


	public function GetPost($guid) {
			$this->object_guid = $guid;
			return $this->getObjectById();
	}
} //class
