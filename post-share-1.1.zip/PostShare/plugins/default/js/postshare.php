//<script>
/*BOF Share Link Functionality*/
$(document).ready(function(){
	$('li a.post-control-share ').hover(function(){
		//console.log("Hey: " + $(this).text());
		var thisID = $(this).attr('id').replace(/\D/g,'');
		var publicy = 2;
		var privacy = 3;
		if($(this).siblings('.share_pops_privacy').length == 0){
			$(this).parent().append('<div id="sharepop-'+thisID+'" class="share_pops_privacy"><a onclick="Ossn.PostShare(['+thisID+','+publicy+']);">Public</a><br /><a onclick="Ossn.PostShare(['+thisID+','+privacy+']);">Private</a></div>');
		}
		
		$(this).mouseenter(function(){
			if($(this).text() == "Share"){
				$(this).siblings('.share_pops_privacy').show();
			}
		});
		$('.share_pops_privacy').mouseleave(function(){
			$('.share_pops_privacy').hide();
		});
		$('.share_pops_privacy a').click(function(){
			$('.share_pops_privacy').hide();
		});
	});
});



$(document).ready(function(){
	Ossn.PostShare = function(post) {
		Ossn.PostRequest({
			url: Ossn.site_url + 'action/post/share',
			beforeSend: function() {
				$('#ossn-share-' + post).html('<img src="' + Ossn.site_url + 'components/OssnComments/images/loading.gif" />');
			},
			params: '&post=' + post[0] + '&privacy=' + post[1],
			callback: function(callback) {
				if (callback['done'] !== 0) {
					$('#ossn-share-' + post).html("Shared!");
					/*$('#ossn-share-' + post).attr('onClick', 'Ossn.PostUnlike(' + post + ');');*/
				} else {
					$('#ossn-share-' + post).html("Share");
				}
			},
		});

	};
});

/*EOF Share Link Functionality*/


/*BOF Share Link Styling*/
$(document).ready(function() {
	$('li a.post-control-share ').parent().addClass("postShareLi");
});
/*EOF Share Link Styling ... continued in CSS*/