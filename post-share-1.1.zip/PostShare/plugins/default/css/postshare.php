

li.postShareLi{float:right;position:relative;}
li.postShareLi:after{
	font-family: FontAwesome;
	content: "\f064" !important;
	display: inline-block;
	padding-right: 10px;
	vertical-align: middle;
	font-size: 16px;
}

.share_pops_privacy{
	position:absolute;
	top:-30px;
	left:-20px;
	width: 80px;
	height:60px;
	border:solid 1px #CCC;
	border-radius:2px;
	background-color:#FFF;
	padding: 4px 6px;
}
.share_pops_privacy a{padding:4px 6px;}
.share_pops_privacy a:hover{cursor:pointer;}