<?php
/*
* file location: components/PostShare/actions/post/
*/
$pid_to_share = input('post');

$PostShare = new PostShare;

$orig_post_data = $PostShare->GetPost($pid_to_share);

$og_post_desc = json_decode(html_entity_decode($orig_post_data->description));
$new_post_post = ossn_input_escape($og_post_desc->post, true);

//poster guid and owner guid is same as user is posting on its own wall
$PostShare->owner_guid = ossn_loggedin_user()->guid;
$PostShare->poster_guid = ossn_loggedin_user()->guid;

//check if users is not posting on its own wall then change wallowner
$owner = input('wallowner');
if (isset($owner) && !empty($owner)) {
    $PostShare->owner_guid = $owner;
}

//walltype is user
$PostShare->name = 'user';

$post = $new_post_post;
$friends = input('friends');
$location = input('location');
$privacy = input('privacy');

$wallphoto = '';
if(isset($orig_post_data->{'file:wallphoto'}) && $orig_post_data->{'file:wallphoto'} != null){
	$wallphoto = array();
	
	$base_path_file_photo = $Ossn->userdata .'object/';
	$path_file_photo_orig = $Ossn->userdata .'object/'.$pid_to_share.'/'.$orig_post_data->{'file:wallphoto'};
	$file_photo_name = preg_replace('/ossnwall\/images\//', '', $orig_post_data->{'file:wallphoto'});
	$file_photo_ext = pathinfo($file_photo_name, PATHINFO_EXTENSION);
	
	$characters = '123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $file_new_name = '';
    for ($i = 0; $i < 32; $i++) {
        $file_new_name .= $characters[rand(0, $charactersLength - 1)];
    }
	
	$file_new_name = $file_new_name . '.' . $file_photo_ext;
	$wallphoto['file_new_name'] = $file_new_name;
	$wallphoto['base_path_file_photo'] = $base_path_file_photo;
	$wallphoto['path_file_photo_orig'] = $path_file_photo_orig;
	
}

//wall share privacy 
if ($privacy == 2) {
    $access = OSSN_PUBLIC;
} else {
    $access = OSSN_FRIENDS;
}


if ($PostShare->Post($post, $friends, $location, $access, $wallphoto)) {
	if (!ossn_is_xhr()) {
        redirect(REF);
    }/* else {
        header('Content-Type: application/json');
        echo json_encode(array(
                'done' => 1,
                'button' => "Shared!",
            ));
    }*/
	//the call back was causing header already started logs
	
	ossn_trigger_message(ossn_print('post:created'));
	redirect(REF);
} else {
    ossn_trigger_message(ossn_print('post:create:error'), 'error');
    redirect(REF);
}
