<input type="text" name="q" placeholder="<?php echo ossn_print('ossn:search');?>" onblur="if (this.value=='') { this.value=Ossn.Print('ossn:search'); }" onFocus="if (this.value==Ossn.Print('ossn:search')) { this.value='' };"/>
<input type="submit" value="Search" class="btn btn-primary"/>
