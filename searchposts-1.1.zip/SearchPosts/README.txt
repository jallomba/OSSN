SearchPosts
===========

V2.0
fix compatibilitly issue with DisplayUsername component
fix compatibilitly issue with Ossn 5.x pagination

V1.0
This component adds a new facility named 'posts' to Ossn's core search capabilities.
You will be able to search for posts this way.
