<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

define('__SEARCH_POSTS__', ossn_route()->com . 'SearchPosts/');

/**
 * Initialize Component
 *
 * @return void;
 * @access private
 */
function com_search_posts_init() {
		ossn_extend_view('css/ossn.default', 'css/searchposts');
		
		ossn_add_hook('search', 'type:posts', 'com_posts_search_handler');
		
		ossn_register_callback('page', 'load:search', 'com_posts_search_link');
}

/**
 * Online member search page handler
 *
 * @return mixdata;
 * @access private
 */

function com_posts_search_handler($hook, $type, $return, $params) {
	$wall = new OssnWall;
	$query = input('q');
	$search_options = array("search_type" => true, "description" => $query);
	$count_options = array("search_type" => true, "description" => $query, "count" => true);
	$posts = $wall->GetPosts($search_options);
	$count = $wall->GetPosts($count_options);
	$data = $posts;
	// so we have the data. this returns 20 items by default.
	$found['users'] = $data;
	$found['count'] = $count;
	$search         = ossn_plugin_view('searchposts/search/view', $found);
	$search .= ossn_view_pagination($count);
	if(empty($data)) {
		return ossn_print('ossn:search:no:result');
	}
	return $search;
}

/**
 * Add 'Posts' link on search page
 *
 * @return void;
 * @access private
 */
function com_posts_search_link($event, $type, $params) {
		$url = OssnPagination::constructUrlArgs(array(
				'type'
		));
		ossn_register_menu_link('posts', 'com:searchposts:posts', "search?type=posts{$url}", 'search');
}

ossn_register_callback('ossn', 'init', 'com_search_posts_init');
